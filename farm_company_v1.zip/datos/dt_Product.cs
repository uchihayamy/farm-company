﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.DTO
{
    public class dt_Product
    {
        public string Name;
        public int UnitPrice;
        public int UnitPerKilometer;
        public double TaxPerUnitPercentage;
    }
}
