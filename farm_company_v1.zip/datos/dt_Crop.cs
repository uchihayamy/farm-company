﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.DTO
{
    public class dt_Crop
    {
        public dt_Product Product;
        public double Extension;
        public dt_Farmer Farmer;
        public string Status;
    }
}
