﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.DTO
{
    public class dt_Farmer
    {
        public int Document;
        public string Name; 
        public int Stratum;
        public string Gender;
        public string Capitalist;
    }
}
