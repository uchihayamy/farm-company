﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.DTO
{
    public class Dto_Product
    {
        public string Name;
        public int UnitPrice;
        public int UnitPerKilometer;
        public double TaxPerUnitPercentage;
    }
}
