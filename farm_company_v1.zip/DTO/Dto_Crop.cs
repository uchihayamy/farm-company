﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.DTO
{
    public class Dto_Crop
    {
        public Dto_Product Product;
        public double Extension;
        public Dto_Farmer Farmer;
        public string Status;
    }
}
